#!/bin/bash

# Clenergize V3 Documentation Reorganization Script
# Version: 1.0.0
# Date: November 22, 2025
# Purpose: Reorganize 130+ documentation files into industry-standard structure

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}==================================================${NC}"
echo -e "${GREEN}   Clenergize V3 Documentation Reorganization    ${NC}"
echo -e "${GREEN}==================================================${NC}"
echo ""

# Check if we're in the Docs directory
if [[ ! -d "event-schemas" && ! -f "ESG_PLATFORM_OVERVIEW.md" ]]; then
    echo -e "${RED}Error: This script must be run from the Docs directory${NC}"
    echo "Please navigate to the Docs directory and run: ./reorganize_docs.sh"
    exit 1
fi

# Create backup
echo -e "${YELLOW}Creating backup of current documentation...${NC}"
BACKUP_NAME="Docs_Backup_$(date +%Y%m%d_%H%M%S).tar.gz"
cd ..
tar -czf "$BACKUP_NAME" Docs/
echo -e "${GREEN}✓ Backup created: $BACKUP_NAME${NC}"
cd Docs

# Function to create directory if it doesn't exist
create_dir() {
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
        echo -e "${GREEN}✓ Created: $1${NC}"
    fi
}

# Function to copy file with new name
copy_file() {
    if [ -f "$1" ]; then
        cp "$1" "$2"
        echo -e "${GREEN}✓ Moved: $1 -> $2${NC}"
    else
        echo -e "${YELLOW}⚠ Warning: $1 not found${NC}"
    fi
}

echo ""
echo -e "${YELLOW}Creating new folder structure...${NC}"

# Create main directories
create_dir "00-Getting-Started"
create_dir "01-Current-Scope-Phase1/01-Overview"
create_dir "01-Current-Scope-Phase1/02-Service-Specifications"
create_dir "01-Current-Scope-Phase1/03-Implementation-Guides"
create_dir "01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.1"
create_dir "01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.2"
create_dir "01-Current-Scope-Phase1/05-Technical-Decisions"

create_dir "02-Future-Roadmap"
create_dir "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications"
create_dir "02-Future-Roadmap/Phase3-Environmental/Service-Specifications"
create_dir "02-Future-Roadmap/Phase4-Social/Service-Specifications"
create_dir "02-Future-Roadmap/Phase5-Governance/Service-Specifications"
create_dir "02-Future-Roadmap/Phase6-Analytics/Service-Specifications"

create_dir "03-Architecture"
create_dir "04-Development/01-Setup"
create_dir "04-Development/02-Standards"
create_dir "04-Development/03-Templates"
create_dir "04-Development/04-Guides"
create_dir "05-Testing"
create_dir "06-Deployment"
create_dir "07-Security"
create_dir "08-Data/01-Schemas"
create_dir "08-Data/02-Events"
create_dir "08-Data/03-Migration"
create_dir "08-Data/04-Optimization"
create_dir "09-API"
create_dir "10-Operations"
create_dir "11-Governance"
create_dir "12-Archive/Reviews"
create_dir "12-Archive/Legacy"
create_dir "12-Archive/Completed"

echo ""
echo -e "${YELLOW}Moving and renaming files...${NC}"

# 00-Getting-Started
copy_file "ESG_PLATFORM_OVERVIEW.md" "00-Getting-Started/01_Platform_Overview.md"
copy_file "QUICKSTART_GUIDE.md" "00-Getting-Started/02_Quick_Start_Guide.md"
copy_file "PHASE2_Target_Architecture_Overview.md" "00-Getting-Started/03_Architecture_Summary.md"
copy_file "ENVIRONMENT_CONFIGURATION_GUIDE.md" "00-Getting-Started/04_Development_Environment.md"
copy_file "PROJECT_STRUCTURE_GUIDE.md" "00-Getting-Started/05_Project_Structure.md"

# 01-Current-Scope-Phase1/01-Overview
copy_file "CURRENT-SCOPE/PHASE1_OVERVIEW.md" "01-Current-Scope-Phase1/01-Overview/01_Phase1_Scope.md"
copy_file "PHASE4_Delivery_Phasing_Plan.md" "01-Current-Scope-Phase1/01-Overview/02_Sprint_Planning.md"
echo "# Phase 1 Delivery Timeline" > "01-Current-Scope-Phase1/01-Overview/03_Delivery_Timeline.md"

# 01-Current-Scope-Phase1/02-Service-Specifications
copy_file "PHASE3_Service_Spec_01_Identity.md" "01-Current-Scope-Phase1/02-Service-Specifications/01_Identity_Service.md"
copy_file "PHASE3_Service_Spec_02_Organization.md" "01-Current-Scope-Phase1/02-Service-Specifications/02_Organization_Service.md"
copy_file "PHASE3_Service_Spec_03_Reference.md" "01-Current-Scope-Phase1/02-Service-Specifications/03_Reference_Service.md"
copy_file "PHASE3_Service_Spec_04_Activity.md" "01-Current-Scope-Phase1/02-Service-Specifications/04_Activity_Service.md"
copy_file "PHASE3_Service_Spec_05_Calculation.md" "01-Current-Scope-Phase1/02-Service-Specifications/05_Calculation_Service.md"
copy_file "PHASE3_Service_Spec_06_Reporting.md" "01-Current-Scope-Phase1/02-Service-Specifications/06_Reporting_Service.md"
copy_file "PHASE3_Service_Spec_07_Audit.md" "01-Current-Scope-Phase1/02-Service-Specifications/07_Audit_Service.md"
copy_file "API_GATEWAY_SPECIFICATION.md" "01-Current-Scope-Phase1/02-Service-Specifications/08_Gateway_Service.md"
copy_file "PHASE3_Service_Specs_Summary.md" "01-Current-Scope-Phase1/02-Service-Specifications/README.md"

# 01-Current-Scope-Phase1/03-Implementation-Guides
copy_file "NESTJS_SERVICE_TEMPLATE_DESIGN.md" "01-Current-Scope-Phase1/03-Implementation-Guides/01_Service_Template_Guide.md"
copy_file "PHASE9_Frontend_Adaptation_Plan.md" "01-Current-Scope-Phase1/03-Implementation-Guides/02_Frontend_Implementation.md"
copy_file "FRONTEND_BACKEND_INTEGRATION_GUIDE.md" "01-Current-Scope-Phase1/03-Implementation-Guides/03_API_Integration_Guide.md"
copy_file "OLD_TO_NEW_MIGRATION_GUIDE.md" "01-Current-Scope-Phase1/03-Implementation-Guides/04_Database_Migration.md"
copy_file "EVENT_SCHEMA_REGISTRY.md" "01-Current-Scope-Phase1/03-Implementation-Guides/05_Event_Implementation.md"
copy_file "PHASE5_SDLC_Quality_Strategy.md" "01-Current-Scope-Phase1/03-Implementation-Guides/06_Testing_Strategy.md"

# 01-Current-Scope-Phase1/04-Sprint-Documentation
copy_file "SPRINT_0.1_Task_Checklist.md" "01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.1/01_Task_Checklist.md"
copy_file "SPRINT_0.1_PROGRESS_DAY1.md" "01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.1/02_Progress_Day1.md"
echo "# Sprint 0.1 Review Summary" > "01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.1/03_Review_Summary.md"

# 01-Current-Scope-Phase1/05-Technical-Decisions
copy_file "PHASE2_Microservice_Decomposition_Bounded_Contexts.md" "01-Current-Scope-Phase1/05-Technical-Decisions/01_Microservice_Boundaries.md"
copy_file "DESIGN/Event_Sourcing_Patterns.md" "01-Current-Scope-Phase1/05-Technical-Decisions/02_Event_Sourcing_Patterns.md"
copy_file "JWT_JWKS_ARCHITECTURE.md" "01-Current-Scope-Phase1/05-Technical-Decisions/03_Security_Architecture.md"

# 02-Future-Roadmap
copy_file "FUTURE-ROADMAP/PLATFORM_ROADMAP_OVERVIEW.md" "02-Future-Roadmap/README.md"
copy_file "ESG_PLATFORM_GAP_ANALYSIS_AND_RECOMMENDATIONS.md" "02-Future-Roadmap/00_ESG_Platform_Vision.md"

# Future Roadmap Service Specifications
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/08_Notification_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/08_Notification_Service.md"
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/09_Workflow_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/09_Workflow_Service.md"
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/10_Integration_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/10_Integration_Service.md"
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/37_Policy_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/37_Policy_Service.md"
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/38_Stakeholder_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/38_Stakeholder_Service.md"
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/41_Materiality_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/41_Materiality_Service.md"
copy_file "FUTURE-ROADMAP/Phase2-Strategic-ESG/service-specs/42_Strategy_Service.md" "02-Future-Roadmap/Phase2-Strategic-ESG/Service-Specifications/42_Strategy_Service.md"

copy_file "FUTURE-ROADMAP/Phase3-Environmental/service-specs/12_Water_Service.md" "02-Future-Roadmap/Phase3-Environmental/Service-Specifications/12_Water_Service.md"
copy_file "FUTURE-ROADMAP/Phase3-Environmental/service-specs/14_Biodiversity_Service.md" "02-Future-Roadmap/Phase3-Environmental/Service-Specifications/14_Biodiversity_Service.md"
copy_file "FUTURE-ROADMAP/Phase3-Environmental/service-specs/15_Energy_Service.md" "02-Future-Roadmap/Phase3-Environmental/Service-Specifications/15_Energy_Service.md"
copy_file "FUTURE-ROADMAP/Phase3-Environmental/service-specs/18_ClimateRisk_Service.md" "02-Future-Roadmap/Phase3-Environmental/Service-Specifications/18_ClimateRisk_Service.md"
copy_file "FUTURE-ROADMAP/Phase3-Environmental/service-specs/20_EnvironmentalSupplyChain_Service.md" "02-Future-Roadmap/Phase3-Environmental/Service-Specifications/20_Environmental_SupplyChain.md"

copy_file "FUTURE-ROADMAP/Phase4-Social/service-specs/21_Workforce_Service.md" "02-Future-Roadmap/Phase4-Social/Service-Specifications/21_Workforce_Service.md"
copy_file "FUTURE-ROADMAP/Phase4-Social/service-specs/23_Labor_Service.md" "02-Future-Roadmap/Phase4-Social/Service-Specifications/23_Labor_Service.md"
copy_file "FUTURE-ROADMAP/Phase4-Social/service-specs/24_Community_Service.md" "02-Future-Roadmap/Phase4-Social/Service-Specifications/24_Community_Service.md"
copy_file "FUTURE-ROADMAP/Phase4-Social/service-specs/25_Product_Service.md" "02-Future-Roadmap/Phase4-Social/Service-Specifications/25_Product_Service.md"
copy_file "FUTURE-ROADMAP/Phase4-Social/service-specs/26_SocialSupplyChain_Service.md" "02-Future-Roadmap/Phase4-Social/Service-Specifications/26_Social_SupplyChain.md"
copy_file "FUTURE-ROADMAP/Phase4-Social/service-specs/30_Training_Service.md" "02-Future-Roadmap/Phase4-Social/Service-Specifications/30_Training_Service.md"

copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/31_Board_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/31_Board_Service.md"
copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/33_Risk_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/33_Risk_Service.md"
copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/34_Privacy_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/34_Privacy_Service.md"
copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/35_Cybersecurity_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/35_Cybersecurity_Service.md"
copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/36_BusinessConduct_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/36_BusinessConduct_Service.md"
copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/39_Transparency_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/39_Transparency_Service.md"
copy_file "FUTURE-ROADMAP/Phase5-Governance/service-specs/40_Controls_Service.md" "02-Future-Roadmap/Phase5-Governance/Service-Specifications/40_Controls_Service.md"

copy_file "FUTURE-ROADMAP/Phase6-Analytics/service-specs/45_Analytics_Service.md" "02-Future-Roadmap/Phase6-Analytics/Service-Specifications/45_Analytics_Service.md"
copy_file "FUTURE-ROADMAP/Phase6-Analytics/service-specs/46_ML_Service.md" "02-Future-Roadmap/Phase6-Analytics/Service-Specifications/46_ML_Service.md"
copy_file "FUTURE-ROADMAP/Phase6-Analytics/service-specs/47_Forecast_Service.md" "02-Future-Roadmap/Phase6-Analytics/Service-Specifications/47_Forecast_Service.md"
copy_file "FUTURE-ROADMAP/Phase6-Analytics/service-specs/48_Scenario_Service.md" "02-Future-Roadmap/Phase6-Analytics/Service-Specifications/48_Scenario_Service.md"
copy_file "FUTURE-ROADMAP/Phase6-Analytics/service-specs/49_Rating_Service.md" "02-Future-Roadmap/Phase6-Analytics/Service-Specifications/49_Rating_Service.md"
copy_file "FUTURE-ROADMAP/Phase6-Analytics/service-specs/50_Insights_Service.md" "02-Future-Roadmap/Phase6-Analytics/Service-Specifications/50_Insights_Service.md"

# 03-Architecture
copy_file "PHASE2_Target_Architecture_Overview.md" "03-Architecture/01_System_Architecture_Overview.md"
copy_file "PHASE2_Microservice_Decomposition_Bounded_Contexts.md" "03-Architecture/02_Microservice_Architecture.md"
copy_file "EVENT_SCHEMA_REGISTRY.md" "03-Architecture/03_Event_Driven_Architecture.md"
copy_file "DATABASE_SCHEMA_DESIGN.md" "03-Architecture/04_Database_Architecture.md"
copy_file "API_GATEWAY_SPECIFICATION.md" "03-Architecture/05_API_Gateway_Design.md"
copy_file "SERVICE_DEPENDENCY_DIAGRAM.md" "03-Architecture/06_Service_Dependencies.md"
copy_file "INFRASTRUCTURE_AS_CODE_COMPLETE.md" "03-Architecture/07_Infrastructure_as_Code.md"

# 04-Development/01-Setup
copy_file "ENVIRONMENT_CONFIGURATION_GUIDE.md" "04-Development/01-Setup/01_Environment_Configuration.md"
copy_file "archive/LOCAL_DEV_ENVIRONMENT_Updates.md" "04-Development/01-Setup/02_Docker_Setup.md"
copy_file "MCP_EXECUTOR_GUIDE.md" "04-Development/01-Setup/03_MCP_Executor_Guide.md"
echo "# Local Development Guide" > "04-Development/01-Setup/04_Local_Development.md"

# 04-Development/02-Standards
copy_file "DEVELOPMENT_CHECKLIST.md" "04-Development/02-Standards/01_Coding_Standards.md"
copy_file "GIT_WORKFLOW.md" "04-Development/02-Standards/02_Git_Workflow.md"
copy_file "CODE_REVIEW_POLICY.md" "04-Development/02-Standards/03_Code_Review_Policy.md"
copy_file "DEVELOPMENT_CHECKLIST.md" "04-Development/02-Standards/04_Development_Checklist.md"
copy_file "AGENT_COORDINATION_GUIDE.md" "04-Development/02-Standards/05_Agent_Coordination.md"

# 04-Development/03-Templates
copy_file "NESTJS_SERVICE_TEMPLATE_DESIGN.md" "04-Development/03-Templates/01_NestJS_Service_Template.md"
copy_file "NEXTJS_FRONTEND_TEMPLATE_DESIGN.md" "04-Development/03-Templates/02_NextJS_Frontend_Template.md"
copy_file "SHARED_PACKAGES_DESIGN.md" "04-Development/03-Templates/03_Shared_Packages_Design.md"
copy_file "CICD_PIPELINE_TEMPLATES_DESIGN.md" "04-Development/03-Templates/04_CICD_Pipeline_Templates.md"

# 04-Development/04-Guides
copy_file "OLD_TO_NEW_MIGRATION_GUIDE.md" "04-Development/04-Guides/01_Migration_Guide.md"
copy_file "FRONTEND_BACKEND_INTEGRATION_GUIDE.md" "04-Development/04-Guides/02_Frontend_Backend_Integration.md"
copy_file "PHASE10_BaseAPIClient_Implementation_Guide.md" "04-Development/04-Guides/03_BaseAPI_Client_Guide.md"
copy_file "OPUS_USAGE_GUIDE.md" "04-Development/04-Guides/04_Opus_Usage_Guide.md"

# 05-Testing
copy_file "PHASE5_SDLC_Quality_Strategy.md" "05-Testing/01_Testing_Strategy.md"
echo "# Unit Testing Guide" > "05-Testing/02_Unit_Testing_Guide.md"
echo "# Integration Testing Guide" > "05-Testing/03_Integration_Testing_Guide.md"
copy_file "CONTRACT_TESTING_IMPLEMENTATION_GUIDE.md" "05-Testing/04_Contract_Testing_Guide.md"
echo "# E2E Testing Guide" > "05-Testing/05_E2E_Testing_Guide.md"
copy_file "PERFORMANCE_TARGETS.md" "05-Testing/06_Performance_Testing.md"
copy_file "SECURITY_TESTING_CHECKLIST.md" "05-Testing/07_Security_Testing_Checklist.md"
copy_file "ACCESSIBILITY_TESTING_IMPLEMENTATION.md" "05-Testing/08_Accessibility_Testing.md"
copy_file "CHAOS_ENGINEERING_IMPLEMENTATION.md" "05-Testing/09_Chaos_Engineering.md"
copy_file "TEST_DATA_MANAGEMENT_IMPLEMENTATION.md" "05-Testing/10_Test_Data_Management.md"
copy_file "ROLLBACK_TESTING_FRAMEWORK.md" "05-Testing/11_Rollback_Testing_Framework.md"

# 06-Deployment
echo "# Deployment Overview" > "06-Deployment/01_Deployment_Overview.md"
copy_file "INFRASTRUCTURE_AS_CODE_COMPLETE.md" "06-Deployment/02_Infrastructure_Setup.md"
copy_file "CICD_PIPELINE_TEMPLATES_DESIGN.md" "06-Deployment/03_CICD_Pipeline.md"
copy_file "SERVICE_DISCOVERY_IMPLEMENTATION.md" "06-Deployment/04_Service_Discovery.md"
copy_file "MONITORING_AND_ALERTING_SPEC.md" "06-Deployment/05_Monitoring_and_Alerting.md"
copy_file "PERFORMANCE_SLOS_MONITORING_STRATEGY.md" "06-Deployment/06_Performance_Monitoring.md"
echo "# Disaster Recovery Plan" > "06-Deployment/07_Disaster_Recovery.md"

# 07-Security
echo "# Security Overview" > "07-Security/01_Security_Overview.md"
copy_file "JWT_JWKS_ARCHITECTURE.md" "07-Security/02_JWT_JWKS_Architecture.md"
copy_file "SERVICE_TO_SERVICE_AUTH_IMPLEMENTATION.md" "07-Security/03_Service_Authentication.md"
copy_file "API_GATEWAY_SECURITY_IMPLEMENTATION.md" "07-Security/04_API_Gateway_Security.md"
copy_file "SECRETS_MANAGEMENT_STRATEGY.md" "07-Security/05_Secrets_Management.md"
copy_file "SECURITY_THREAT_MODEL_STRIDE.md" "07-Security/06_Threat_Model_STRIDE.md"
copy_file "MCP_SECURITY_AUDIT.md" "07-Security/07_Security_Audit_Report.md"
echo "# Compliance Requirements" > "07-Security/08_Compliance_Requirements.md"

# 08-Data/01-Schemas
copy_file "DATABASE_SCHEMA_DESIGN.md" "08-Data/01-Schemas/01_Database_Schema_Design.md"
echo "# MongoDB Schemas" > "08-Data/01-Schemas/02_MongoDB_Schemas.md"
echo "# Data Models" > "08-Data/01-Schemas/03_Data_Models.md"

# 08-Data/02-Events
copy_file "event-schemas/README.md" "08-Data/02-Events/README.md"
copy_file "EVENT_SCHEMA_REGISTRY.md" "08-Data/02-Events/01_Event_Schema_Registry.md"
copy_file "event-schemas/00-BASE.md" "08-Data/02-Events/02_Base_Event_Schema.md"
copy_file "event-schemas/01-IDENTITY.md" "08-Data/02-Events/03_Identity_Events.md"
copy_file "event-schemas/02-ORGANIZATION.md" "08-Data/02-Events/04_Organization_Events.md"
copy_file "event-schemas/03-REFERENCE.md" "08-Data/02-Events/05_Reference_Events.md"
copy_file "event-schemas/04-ACTIVITY.md" "08-Data/02-Events/06_Activity_Events.md"
copy_file "event-schemas/05-CALCULATION.md" "08-Data/02-Events/07_Calculation_Events.md"
copy_file "event-schemas/06-REPORTING.md" "08-Data/02-Events/08_Reporting_Events.md"
copy_file "event-schemas/07-AUDIT.md" "08-Data/02-Events/09_Audit_Events.md"
copy_file "event-schemas/99-IMPLEMENTATION-GUIDE.md" "08-Data/02-Events/10_Implementation_Guide.md"

# 08-Data/03-Migration
copy_file "DATA_MIGRATION_ROLLBACK_PLAN.md" "08-Data/03-Migration/01_Data_Migration_Strategy.md"
copy_file "DATA_MIGRATION_SCRIPTS_IMPLEMENTATION.md" "08-Data/03-Migration/02_Migration_Scripts.md"
copy_file "DATA_MIGRATION_ROLLBACK_PLAN.md" "08-Data/03-Migration/03_Rollback_Plan.md"
copy_file "HIERARCHY_MIGRATION_ALGORITHM.md" "08-Data/03-Migration/04_Hierarchy_Migration.md"

# 08-Data/04-Optimization
copy_file "MONGODB_QUERY_OPTIMIZATION_STRATEGY.md" "08-Data/04-Optimization/01_MongoDB_Query_Optimization.md"
copy_file "REDIS_CACHING_STRATEGY.md" "08-Data/04-Optimization/02_Redis_Caching_Strategy.md"
copy_file "PERFORMANCE_TARGETS.md" "08-Data/04-Optimization/03_Performance_Targets.md"

# 09-API
copy_file "API_DESIGN_SPECIFICATION.md" "09-API/01_API_Design_Specification.md"
copy_file "REST_API_SPECIFICATION.md" "09-API/02_REST_API_Specification.md"
copy_file "API_VERSIONING_STRATEGY.md" "09-API/03_API_Versioning_Strategy.md"
copy_file "API_GATEWAY_SPECIFICATION.md" "09-API/04_API_Gateway_Specification.md"
copy_file "ERROR_CODE_REGISTRY.md" "09-API/05_Error_Code_Registry.md"
echo "# API Documentation Guide" > "09-API/06_API_Documentation_Guide.md"

# 10-Operations
echo "# Operational Overview" > "10-Operations/01_Operational_Overview.md"
copy_file "CIRCUIT_BREAKER_AND_RESILIENCE.md" "10-Operations/02_Circuit_Breaker_Patterns.md"
copy_file "SAGA_PATTERN_IMPLEMENTATION.md" "10-Operations/03_Saga_Pattern_Implementation.md"
copy_file "TRANSACTION_BOUNDARY_SPEC.md" "10-Operations/04_Transaction_Boundaries.md"
echo "# Service Health Checks" > "10-Operations/05_Service_Health_Checks.md"
echo "# Incident Response" > "10-Operations/06_Incident_Response.md"

# 11-Governance
echo "# Project Governance" > "11-Governance/01_Project_Governance.md"
copy_file "CLAUDE_MULTI_AGENT_STRATEGY.md" "11-Governance/02_Multi_Agent_Strategy.md"
copy_file "JIRA_ESG_STRUCTURE.md" "11-Governance/03_JIRA_Structure.md"
echo "# Review Process" > "11-Governance/04_Review_Process.md"
copy_file "DOCUMENTATION_STRUCTURE.md" "11-Governance/05_Documentation_Standards.md"

# 12-Archive
copy_file "REVIEW_SUMMARY_2025-11-18.md" "12-Archive/Reviews/Review_2025-11-18.md"
copy_file "REVIEW_SUMMARY_2025-11-20.md" "12-Archive/Reviews/Review_2025-11-20.md"
copy_file "PHASE1_Current_Architecture_Overview.md" "12-Archive/Legacy/Current_Architecture.md"
copy_file "COMPANYDETAILS_MIGRATION.md" "12-Archive/Legacy/Company_Details_Migration.md"
copy_file "archive/completed-setup/PHASE6_Jira_MCP_Configuration.md" "12-Archive/Completed/JIRA_MCP_Configuration.md"
copy_file "archive/completed-setup/PHASE7_Complete_Jira_Backlog.md" "12-Archive/Completed/JIRA_Backlog_Complete.md"
copy_file "archive/LOCAL_DEV_ENVIRONMENT_Updates.md" "12-Archive/Completed/Local_Dev_Environment.md"

echo ""
echo -e "${YELLOW}Creating README files...${NC}"

# Create master README
cat > README.md << 'EOF'
# Clenergize V3 ESG Platform Documentation

Welcome to the comprehensive documentation for the Clenergize V3 ESG Platform. This documentation is organized to support both current development (Phase 1: Carbon Footprint) and future roadmap (Phases 2-6: Full ESG Platform).

## Quick Navigation

### 🚀 Getting Started
- [Platform Overview](00-Getting-Started/01_Platform_Overview.md)
- [Quick Start Guide](00-Getting-Started/02_Quick_Start_Guide.md)
- [Architecture Summary](00-Getting-Started/03_Architecture_Summary.md)
- [Development Environment](00-Getting-Started/04_Development_Environment.md)
- [Project Structure](00-Getting-Started/05_Project_Structure.md)

### 📂 Documentation Structure

#### Active Development (Phase 1: Carbon Footprint - Months 1-8)
- **[01-Current-Scope-Phase1](01-Current-Scope-Phase1/)** - Everything needed for current sprint work
  - [Service Specifications](01-Current-Scope-Phase1/02-Service-Specifications/) - Core services for carbon platform
  - [Implementation Guides](01-Current-Scope-Phase1/03-Implementation-Guides/) - How-to guides
  - [Sprint Documentation](01-Current-Scope-Phase1/04-Sprint-Documentation/) - Current sprint progress
  - [Technical Decisions](01-Current-Scope-Phase1/05-Technical-Decisions/) - ADRs and design choices

#### Future Roadmap (Phases 2-6: Full ESG - Months 9-19)
- **[02-Future-Roadmap](02-Future-Roadmap/)** - Planned ESG platform expansion
  - [Phase 2: Strategic ESG](02-Future-Roadmap/Phase2-Strategic-ESG/) - Foundation services
  - [Phase 3: Environmental](02-Future-Roadmap/Phase3-Environmental/) - Environmental services
  - [Phase 4: Social](02-Future-Roadmap/Phase4-Social/) - Social services
  - [Phase 5: Governance](02-Future-Roadmap/Phase5-Governance/) - Governance services
  - [Phase 6: Analytics](02-Future-Roadmap/Phase6-Analytics/) - ML and analytics

#### Technical Documentation
- **[03-Architecture](03-Architecture/)** - System architecture and design patterns
- **[04-Development](04-Development/)** - Development guides, standards, and templates
- **[05-Testing](05-Testing/)** - Testing strategies and implementation guides
- **[06-Deployment](06-Deployment/)** - Deployment, infrastructure, and monitoring
- **[07-Security](07-Security/)** - Security architecture and compliance
- **[08-Data](08-Data/)** - Data schemas, events, and migration
- **[09-API](09-API/)** - API specifications and standards
- **[10-Operations](10-Operations/)** - Operational procedures and patterns
- **[11-Governance](11-Governance/)** - Project governance and processes

## For New Developers

1. **Start Here**: [Platform Overview](00-Getting-Started/01_Platform_Overview.md)
2. **Setup**: [Quick Start Guide](00-Getting-Started/02_Quick_Start_Guide.md)
3. **Current Work**: [Sprint 0.1 Tasks](01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.1/)
4. **Your Service**: [Service Specifications](01-Current-Scope-Phase1/02-Service-Specifications/)

## Document Naming Convention

- **Folders**: 2-digit prefix (00, 01, 02...) for ordering
- **Files**: 2-digit prefix + descriptive name with underscores
- **Example**: `01_Identity_Service.md`

## Platform Scope

### Current Development (Phase 1)
- **Timeline**: Months 1-8 (Sprints 0.1 - 1.5)
- **Focus**: Carbon Footprint Management
- **Services**: 7 core microservices
- **Deliverable**: Production-ready carbon platform

### Future Roadmap (Phases 2-6)
- **Timeline**: Months 9-19
- **Focus**: Complete ESG Platform
- **Services**: 50+ microservices
- **Coverage**: Environmental, Social, Governance dimensions

## Version Control

- **Documentation Version**: 1.0.0
- **Last Updated**: November 22, 2025
- **Total Documents**: 130+ markdown files
- **Active Sprint**: Sprint 0.1

## Quick Links

### Development Resources
- [Local Environment Setup](00-Getting-Started/04_Development_Environment.md)
- [Service Template Guide](01-Current-Scope-Phase1/03-Implementation-Guides/01_Service_Template_Guide.md)
- [Git Workflow](04-Development/02-Standards/02_Git_Workflow.md)
- [Code Review Policy](04-Development/02-Standards/03_Code_Review_Policy.md)

### Architecture & Design
- [System Architecture](03-Architecture/01_System_Architecture_Overview.md)
- [Microservice Boundaries](03-Architecture/02_Microservice_Architecture.md)
- [Event-Driven Architecture](03-Architecture/03_Event_Driven_Architecture.md)
- [Database Design](03-Architecture/04_Database_Architecture.md)

### Testing & Quality
- [Testing Strategy](05-Testing/01_Testing_Strategy.md)
- [Contract Testing](05-Testing/04_Contract_Testing_Guide.md)
- [Security Testing](05-Testing/07_Security_Testing_Checklist.md)

### Operations & Deployment
- [Deployment Guide](06-Deployment/01_Deployment_Overview.md)
- [Monitoring Setup](06-Deployment/05_Monitoring_and_Alerting.md)
- [Incident Response](10-Operations/06_Incident_Response.md)

## Support

For questions about documentation:
- Slack: #clenergize-docs
- Email: docs@clenergize.com
- GitHub Issues: [Report Documentation Issue](https://github.com/clenergize/v3/issues)

## Contributing

Please follow our [Documentation Standards](11-Governance/05_Documentation_Standards.md) when contributing to documentation.

---

**© 2025 Clenergize. All rights reserved.**
EOF

echo -e "${GREEN}✓ Created master README.md${NC}"

# Create Getting Started README
cat > 00-Getting-Started/README.md << 'EOF'
# Getting Started

Welcome to Clenergize V3! This section contains everything you need to understand the platform and start developing.

## Essential Documents

1. **[Platform Overview](01_Platform_Overview.md)** - Comprehensive system overview
2. **[Quick Start Guide](02_Quick_Start_Guide.md)** - Get running in 5 minutes
3. **[Architecture Summary](03_Architecture_Summary.md)** - Key architectural decisions
4. **[Development Environment](04_Development_Environment.md)** - Local setup instructions
5. **[Project Structure](05_Project_Structure.md)** - Repository organization

## Next Steps

After reviewing these documents:
- Check [Current Sprint Tasks](../01-Current-Scope-Phase1/04-Sprint-Documentation/Sprint_0.1/)
- Review your [Service Specification](../01-Current-Scope-Phase1/02-Service-Specifications/)
- Follow the [Development Checklist](../04-Development/02-Standards/04_Development_Checklist.md)
EOF

echo -e "${GREEN}✓ Created category README files${NC}"

# Create placeholders for empty files that were referenced
echo "# Quick Start Guide" > "00-Getting-Started/02_Quick_Start_Guide.md" 2>/dev/null || true
echo "# Architecture Summary" > "00-Getting-Started/03_Architecture_Summary.md" 2>/dev/null || true

echo ""
echo -e "${GREEN}==================================================${NC}"
echo -e "${GREEN}          Reorganization Complete!                ${NC}"
echo -e "${GREEN}==================================================${NC}"
echo ""
echo -e "${YELLOW}Summary:${NC}"
echo "✓ Created new folder structure with 12 main categories"
echo "✓ Moved and renamed 130+ documentation files"
echo "✓ Created navigation README files"
echo "✓ Backup saved as: $BACKUP_NAME"
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo "1. Review the new structure in the Docs directory"
echo "2. Update any code references to old documentation paths"
echo "3. Update .claude/CLAUDE.md with new documentation paths"
echo "4. Notify the team about the new structure"
echo ""
echo -e "${GREEN}Documentation is now organized following industry best practices!${NC}"